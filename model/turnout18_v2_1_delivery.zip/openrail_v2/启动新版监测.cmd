@echo off
cd /d "%~dp0..\turnout_package\itwin-app"
set "PORT=3002"
set "NODE_EXE=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe"
if exist "%NODE_EXE%" (
  "%NODE_EXE%" backend/server.cjs
) else (
  node backend/server.cjs
)
pause
