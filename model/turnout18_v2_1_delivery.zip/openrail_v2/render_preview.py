import bpy
from pathlib import Path
from mathutils import Vector
p=Path(__file__).parent
bpy.ops.wm.open_mainfile(filepath=str(p/'turnout18_components.blend'))
s=bpy.context.scene;s.render.engine='BLENDER_WORKBENCH';s.render.resolution_x=2000;s.render.resolution_y=650;s.render.resolution_percentage=100
s.display.shading.light='STUDIO';s.display.shading.color_type='MATERIAL';s.display.shading.show_shadows=True;s.display.shading.show_cavity=True;s.display.shading.background_type='WORLD';s.world.color=(.8,.8,.8)
cam=bpy.data.cameras.new('PreviewCamera');ob=bpy.data.objects.new('PreviewCamera',cam);s.collection.objects.link(ob);s.camera=ob
ob.location=(36,-34,29);target=Vector((36,-1,0));ob.rotation_euler=(target-ob.location).to_track_quat('-Z','Y').to_euler();cam.type='ORTHO';cam.ortho_scale=79;cam.clip_end=250
s.render.filepath=str(p/'model_overview.png');bpy.ops.render.render(write_still=True)
