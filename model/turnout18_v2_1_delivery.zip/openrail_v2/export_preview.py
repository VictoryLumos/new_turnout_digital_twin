import bpy,json,sys
from pathlib import Path
p=Path(__file__).parent
r=json.loads((p/'source_components.json').read_text(encoding='utf8'))
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
bpy.context.scene.unit_settings.system='METRIC'
mats={}
for c in r['components']:
 layer=c['sourceLayer']
 if layer not in mats:
  mat=bpy.data.materials.new(layer)
  mat.diffuse_color=(.42,.44,.46,1) if 'RAIL' in layer or 'C6D192' in layer else ((.56,.54,.5,1) if 'SLEEPERS' in layer else (.18,.2,.22,1))
  mat.use_nodes=True; bs=mat.node_tree.nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=mat.diffuse_color; bs.inputs['Metallic'].default_value=0 if 'SLEEPERS' in layer or 'RUBBER' in layer else .7; bs.inputs['Roughness'].default_value=.65
  if layer=='DEMO_SWITCH_MACHINES': mat.diffuse_color=(.8,.38,.05,1);bs.inputs['Base Color'].default_value=mat.diffuse_color
  mats[layer]=mat
 center=[(c['bounds']['min_'+a]+c['bounds']['max_'+a])/2000 for a in 'xyz']
 mesh=bpy.data.meshes.new(c['name']);mesh.from_pydata([[v[k]/1000-center[k] for k in range(3)] for v in c['vertices']],[],c['faces']);mesh.update()
 obj=bpy.data.objects.new(c['name'],mesh);bpy.context.collection.objects.link(obj);obj.location=center;obj.data.materials.append(mats[layer])
 for key in ['assetId','sourceLayer','classification']:obj[key]=c[key]
 obj['NodeName']=c['name']
assembly=json.loads((p/'assembly.json').read_text())
root=bpy.data.objects.new('Frog',None);bpy.context.collection.objects.link(root);root['assetId']=assembly['assetId'];root['kind']='logical_assembly'
for name in assembly['children']: bpy.data.objects[name].parent=root
bpy.ops.wm.save_as_mainfile(filepath=str(p/'turnout18_components.blend'))
bpy.ops.export_scene.gltf(filepath=str(p/'turnout18_components.glb'),export_format='GLB',export_extras=True)
print('EXPORTED',len(r['components']))

