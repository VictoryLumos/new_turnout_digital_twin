# 本地 iTwin.js 查看器 V2.1

访问 http://127.0.0.1:3002/ ，停止后双击上一级“启动新版监测.cmd”。旧3001页面不用于本轮验收。

turnout.bim为2902构件本地快照，与DGN共享source_components.json输入，已含护轨高度修正。它不是Bentley连接器同步生成的云iModel。源码在../../turnout_package/itwin-app。

五点设计动程为160/118/75/100.6/55.5 mm。WebSocket每1.5秒重播上一级data.json，时间戳代表演示发送时间。未正式连接真实传感器。

仅SwitchRail、PointRail主节点按>150/>100演示条件变红；没有运动变形。其他三点未设置告警阈值。红色不代表工程故障结论。

已验证ECSQL查询、2902唯一元素及资产、包围盒、保存视图、五路数据和阈值边界，见validation.json及integration-validation.json。上一版显示和变红获用户确认，本轮五点表格已请用户目视检查。

迁移时须安装package.json和锁文件指定依赖，包中不含node_modules。Bentley云项目/连接器/AssetWise尚未接通。
