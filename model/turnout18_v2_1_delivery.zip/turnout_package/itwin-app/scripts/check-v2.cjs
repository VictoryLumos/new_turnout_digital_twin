const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const ts=require('typescript');
const WebSocket=require('ws');
async function main(){
 const out=path.resolve(__dirname,'../../../openrail_v2/local_imodel');
 const code=ts.transpileModule(fs.readFileSync(path.join(__dirname,'../src/telemetry.ts'),'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
 const context={exports:{}};vm.runInNewContext(code,context);const {parseTelemetry,alarmState,dataIsFresh}=context.exports;
 for(const [connected,received,now,expected] of [[false,1000,1001,false],[true,0,1000,false],[true,1000,1000,true],[true,1000,6000,true],[true,1000,6001,false],[true,2000,1000,false]])
  assert.equal(dataIsFresh(connected,received,now),expected);
 assert.equal(parseTelemetry({time:'invalid',switchRailDisp1:160,pointRailDisp1:101}),undefined);
 assert.equal(parseTelemetry({time:new Date().toISOString(),switchRailDisp1:'160',pointRailDisp1:101}),undefined);
 for(const [sw,pt,swAlarm,ptAlarm] of [[150,100,false,false],[150.1,100,true,false],[150,100.1,false,true],[160,100.6,true,true],[0,0,false,false]]){
  const alarms=alarmState({switchRailDisp1:sw,pointRailDisp1:pt});assert.equal(alarms.SwitchRail,swAlarm);assert.equal(alarms.PointRail,ptAlarm);
 }
 const config=await(await fetch('http://127.0.0.1:3002/api/model')).json();assert.equal(config.elementCount,2902);
 const design=await(await fetch('http://127.0.0.1:3002/api/design')).json();
 assert.deepEqual(design.points.map(x=>x.strokeMm),[160,118,75,100.6,55.5]);
 assert.deepEqual(design.points.map(x=>x.theoreticalForceN),[837,699,2254,179,4529]);
 assert.equal(design.sensorConnection,'NOT_CONNECTED');
 const complete={time:new Date().toISOString(),switchRailDisp1:160,switchRailDisp2:118,switchRailDisp3:75,pointRailDisp1:100.6,pointRailDisp2:55.5};
 assert(parseTelemetry(complete));
 assert.equal(parseTelemetry({...complete,pointRailDisp2:undefined}),undefined);
 assert.equal(parseTelemetry({...complete,switchRailDisp3:Infinity}),undefined);
 const mapping=await(await fetch('http://127.0.0.1:3002/api/mapping')).json();assert.equal(mapping.elements.length,2902);assert.equal(new Set(mapping.elements.map(x=>x.elementId)).size,2902);
 for(const name of ['SwitchRail','PointRail','SwitchMachine','SwitchMachine_02','SwitchMachine_03','PointMachine','PointMachine_02'])assert(mapping.elements.find(x=>x.nodeName===name));
 const packets=await new Promise((resolve,reject)=>{
  const ws=new WebSocket('ws://127.0.0.1:3002/telemetry');const results=[];const timeout=setTimeout(()=>{ws.close();reject(Error('WebSocket timeout'));},10000);
  ws.on('error',e=>{clearTimeout(timeout);reject(e);});ws.on('message',b=>{try{const data=JSON.parse(b);assert(parseTelemetry(data));assert(Math.abs(Date.now()-Date.parse(data.time))<5000);results.push(data);if(results.length===3){clearTimeout(timeout);ws.close();resolve(results);}}catch(e){clearTimeout(timeout);ws.close();reject(e);}});
 });
 assert.equal(packets[2].switchRailDisp1,160);assert.equal(packets[2].pointRailDisp1,100.6);
 assert.equal(packets[2].pointRailDisp2,55.5);assert.equal(packets[2].switchRailDisp2,118);assert.equal(packets[2].switchRailDisp3,75);
 const result={status:'PASS',apiElementCount:2902,designPoints:5,realSensorsConnected:false,webSocketPackets:packets.length,thresholdBoundaryTests:5,invalidTelemetryTests:4,freshnessTests:6,visualReview:'five-point and freshness update pending user'};
 fs.writeFileSync(path.join(out,'integration-validation.json'),JSON.stringify(result,null,2));console.log(result);
}
main().catch(e=>{console.error(e);process.exitCode=1;});
