// Deterministic official iTwin native runtime installation. Also works after
// npm/pnpm --ignore-scripts; verifies npm's SHA-512 before extracting the archive.
const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");
const { createRequire } = require("node:module");
const { spawnSync } = require("node:child_process");
async function get(url) {
  for (let attempt=0;attempt<3;attempt++) {
    try {
      const response=await fetch(url,{signal:AbortSignal.timeout(180000)});
      if (!response.ok) throw Error(`HTTP ${response.status}: ${url}`);
      return Buffer.from(await response.arrayBuffer());
    } catch(error) {if(attempt===2) throw error;console.log("Retrying official runtime download…");}
  }
}
async function main() {
  const req=createRequire(require.resolve("@itwin/core-backend"));
  const nativeRoot=path.dirname(req.resolve("@bentley/imodeljs-native/package.json"));
  const version=JSON.parse(fs.readFileSync(path.join(nativeRoot,"package.json"),"utf8")).version;
  const packageName=`imodeljs-${process.platform}-${process.arch}`;
  const target=path.join(nativeRoot,packageName);
  if (fs.existsSync(path.join(target,"imodeljs.node"))) return;
  const info=JSON.parse(await get(`https://registry.npmjs.org/@bentley/${packageName}/${version}`));
  console.log(`Installing official @bentley/${packageName}@${version}…`);
  const bytes=await get(info.dist.tarball);
  const integrity="sha512-"+crypto.createHash("sha512").update(bytes).digest("base64");
  if (info.dist.integrity!==integrity) throw Error("Native archive integrity mismatch");
  const cache=path.resolve(__dirname,"../../.cache");
  fs.mkdirSync(cache,{recursive:true});
  const archive=path.join(cache,`${packageName}-${version}.tgz`);
  fs.writeFileSync(archive,bytes);
  fs.mkdirSync(target,{recursive:true});
  const result=spawnSync("tar",["-xzf",archive,"--strip-components=1","-C",target],{stdio:"inherit",windowsHide:true});
  if(result.error) throw result.error;
  if(result.status!==0 || !fs.existsSync(path.join(target,"imodeljs.node"))) throw Error("Native runtime extraction failed; Windows 10/11 tar is required.");
  console.log("Native runtime verified and installed.");
}
main().catch(error=>{console.error(error);process.exitCode=1;});
