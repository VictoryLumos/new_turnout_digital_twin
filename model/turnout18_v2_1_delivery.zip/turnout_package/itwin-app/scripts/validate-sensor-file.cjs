// node scripts/validate-sensor-file.cjs path/to/frame.json
const fs=require('node:fs');
const {validateFrame}=require('../backend/telemetry-contract.cjs');
try {
 if(!process.argv[2])throw Error('请提供厂家适配后的JSON文件路径。');
 const frame=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));
 const result=validateFrame(frame);
 console.log(JSON.stringify({...result,acceptedForLive:false,mode:'VALIDATION_ONLY'},null,2));
 if(!result.valid)process.exitCode=1;
}catch(e){console.error(e.message);process.exitCode=1;}
