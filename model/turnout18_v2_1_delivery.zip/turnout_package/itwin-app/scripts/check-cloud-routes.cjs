const assert = require('node:assert/strict');
(async () => {
 for (const route of ['/', '/?mode=cloud', '/signin-callback']) {
  const response = await fetch('http://localhost:3002' + route);
  const html = await response.text();
  assert.equal(response.status, 200, route);
  assert(html.includes('id="root"'), route);
  if (route === '/signin-callback') assert.equal(response.headers.get('cache-control'), 'no-store');
 }
 console.log('PASS: localhost home, cloud entry and login callback routes. Actual Bentley authentication still requires browser verification.');
})().catch(e => { console.error(e); process.exitCode=1; });
