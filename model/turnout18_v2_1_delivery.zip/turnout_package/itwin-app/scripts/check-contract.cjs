const assert=require('node:assert/strict');
const {fields,validateFrame}=require('../backend/telemetry-contract.cjs');
const now=Date.now();
const frame={schemaVersion:'1.0',time:new Date(now).toISOString(),dataSource:'REAL',unit:'mm',sensorIds:Object.fromEntries(fields.map((f,i)=>[f,`TEST-CHANNEL-${i}`])),...Object.fromEntries(fields.map(f=>[f,0]))};
assert(validateFrame(frame,{now}).valid);
for(const bad of [{unit:'m'},{schemaVersion:'2'},{dataSource:'UNKNOWN'},{sensorIds:{}},{pointRailDisp2:null},{switchRailDisp1:'160'},{pointRailDisp1:Infinity},{time:new Date(now-11000).toISOString()}]) assert(!validateFrame({...frame,...bad},{now}).valid);
assert(!validateFrame(frame,{now,lastTime:now}).valid);
assert(validateFrame({...frame,dataSource:'SIMULATED',sensorIds:undefined},{now}).valid);
async function main(){
 const base='http://127.0.0.1:3002';
 const components=await(await fetch(base+'/api/components')).json();
 assert.equal(components.length,2902);assert.equal(new Set(components.map(c=>c.nodeName)).size,2902);
 for(const c of components){assert(c.assetId);assert.equal(c.bounds.length,6);assert(c.bounds.every(Number.isFinite));for(let i=0;i<3;i++)assert(c.bounds[i]<=c.bounds[i+3]);}
 for(const unit of ['mm','m']){
   const response=await fetch(base+'/api/telemetry/validate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...frame,time:new Date().toISOString(),unit})});
   assert.equal(response.status,unit==='mm'?200:422);const body=await response.json();assert.equal(body.acceptedForLive,false);assert.equal(body.mode,'VALIDATION_ONLY');
 }
 console.log('PASS: 2902 component bounds; real/simulated dry-run frames; units, missing channels, duplicate time and invalid data; no live acceptance.');
}
main().catch(e=>{console.error(e);process.exitCode=1;});
