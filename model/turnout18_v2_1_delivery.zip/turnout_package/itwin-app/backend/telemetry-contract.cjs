// Preparation only: validates proposed adapter frames; never publishes to the live feed.
const fields=['switchRailDisp1','switchRailDisp2','switchRailDisp3','pointRailDisp1','pointRailDisp2'];
function validateFrame(value, {now=Date.now(), lastTime=-Infinity}={}) {
  const errors=[];
  if(!value || typeof value!=='object' || Array.isArray(value)) return {valid:false,errors:['报文必须是JSON对象']};
  if(value.schemaVersion!=='1.0') errors.push('schemaVersion必须为1.0');
  if(!['SIMULATED','REAL'].includes(value.dataSource)) errors.push('dataSource必须为SIMULATED或REAL');
  if(value.unit!=='mm') errors.push('unit必须为mm；上游需先转换单位');
  const utc=typeof value.time==='string'&&/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d{1,3})?Z$/.test(value.time);
  const time=utc?Date.parse(value.time):NaN;
  if(!Number.isFinite(time)) errors.push('time必须是UTC ISO时间');
  else {
    if(Math.abs(now-time)>10000) errors.push('采集时间与接收时间差超过10秒');
    if(time<=lastTime) errors.push('重复或倒序采集时间');
  }
  for(const field of fields) {
    if(typeof value[field]!=='number'||!Number.isFinite(value[field])) errors.push(`${field}必须为有限数值`);
    if(value.dataSource==='REAL' && (typeof value.sensorIds?.[field]!=='string'||!value.sensorIds[field].trim())) errors.push(`${field}缺少真实传感器编号`);
  }
  if(value.dataSource==='REAL' && new Set(fields.map(f=>value.sensorIds?.[f])).size!==fields.length) errors.push('五个测量通道编号必须唯一（多通道设备请带通道后缀）');
  if(errors.length)return {valid:false,errors};
  return {valid:true,errors:[],normalized:{schemaVersion:'1.0',time:value.time,dataSource:value.dataSource,unit:'mm',...Object.fromEntries(fields.map(f=>[f,value[f]])),...(value.dataSource==='REAL'?{sensorIds:Object.fromEntries(fields.map(f=>[f,value.sensorIds[f]]))}:{})}};
}
module.exports={fields,validateFrame};
