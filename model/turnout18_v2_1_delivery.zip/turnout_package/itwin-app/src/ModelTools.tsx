import { useEffect, useState } from "react";
import { IModelApp, ScreenViewport } from "@itwin/core-frontend";
import { Placement3d, QueryRowFormat } from "@itwin/core-common";
import { Point3d, Range3d } from "@itwin/core-geometry";

type Component = {nodeName:string; assetId:string; geometryStatus:string; bounds:number[]};
type Point = {code:string;label:string;modelNodeName:string;actuatorNodeName:string;strokeMm:number};
export function ModelTools({viewport, cloud, points}:{viewport:ScreenViewport;cloud:boolean;points:Point[]}) {
  const [catalog,setCatalog]=useState<Map<string,Component>>(new Map());
  const [elements,setElements]=useState<Map<string,string>>(new Map());
  const [selected,setSelected]=useState<Component>();
  const [message,setMessage]=useState("正在读取构件目录…");
  const [busy,setBusy]=useState(false);
  const [report,setReport]=useState<string>();
  useEffect(()=>{
    let disposed=false;
    let remove:(()=>void)|undefined;
    void (async()=>{
      try {
        const response=await fetch("/api/components");
        if(!response.ok) throw Error("构件目录读取失败，请重启新版服务。");
        const list:Component[]=await response.json();
        const byName=new Map(list.map(x=>[x.nodeName,x]));
        const sql=cloud ? "SELECT a.Element.Id AS elementId,a.NodeName AS nodeName,a.AssetId AS assetId FROM DgnCustomItemTypes_TurnoutAssets.ComponentElementAspect a" : "SELECT ECInstanceId AS elementId,UserLabel AS nodeName FROM BisCore.GeometricElement3d";
        const rows=await viewport.iModel.createQueryReader(sql,undefined,{rowFormat:QueryRowFormat.UseJsPropertyNames}).toArray();
        if(disposed) return;
        const byId=new Map<string,string>();
        for(const row of rows) {
          const entry=byName.get(row.nodeName);
          if(!entry || (cloud && row.assetId!==entry.assetId)) throw Error("构件目录与当前模型资产编码不一致。");
          byId.set(row.elementId,row.nodeName);
        }
        if(byId.size!==list.length || new Set(byId.values()).size!==list.length) throw Error("构件目录不完整或名称重复。");
        setCatalog(byName);setElements(byId);setMessage("点击模型构件查看信息，或使用定位按钮。");
        remove=viewport.iModel.selectionSet.onChanged.addListener(()=>{
          const id=[...viewport.iModel.selectionSet.elements][0];
          setSelected(byName.get(byId.get(id)??""));
        });
        await IModelApp.tools.run("Select");
      } catch(e) {if(!disposed)setMessage(e instanceof Error?e.message:String(e));}
    })();
    return ()=>{disposed=true;remove?.();};
  },[viewport,cloud]);
  async function locate(name?:string) {
    setBusy(true);
    try {
      const ids=[...elements].filter(([,n])=>!name || n===name).map(([id])=>id);
      if(!ids.length) throw Error("构件目录尚未就绪。");
      if(name) viewport.iModel.selectionSet.replace(ids);else viewport.iModel.selectionSet.emptyAll();
      await viewport.zoomToElements(ids,{animateFrustumChange:true,minimumDimension:2});
    }catch(e){setMessage(e instanceof Error?e.message:String(e));}finally{setBusy(false);}
  }
  async function audit() {
    setBusy(true);setReport(undefined);
    try {
      const ids=[...elements.keys()];
      const results:unknown[]=[];let failures=0,maxError=0;
      for(let i=0;i<ids.length;i+=150) {
        setMessage(`正在核对位置和尺寸：${i}/${ids.length}`);
        const props=await viewport.iModel.elements.getProps(ids.slice(i,i+150));
        if(props.length!==Math.min(150,ids.length-i)) throw Error("模型返回的构件数量不完整。");
        for(const p of props) {
          const expected=catalog.get(elements.get(p.id!)!);
          const placement=(p as unknown as {placement?:Parameters<typeof Placement3d.fromJSON>[0]}).placement;
          if(!expected || !placement) throw Error("构件缺少放置位置，无法核验。");
          const placed=Placement3d.fromJSON(placement);
          const r=placed.calculateRange();
          const actual=[r.low.x,r.low.y,r.low.z,r.high.x,r.high.y,r.high.z];
          const worldBoxError=Math.max(...actual.map((v,k)=>Math.abs(v-expected.bounds[k])));
          let error=worldBoxError;
          let method="WORLD_RANGE";
          let localComparison:unknown;
          // A transformed local AABB is conservative, especially for curved rails.
          // Compare source vertices in the SAME local frame before declaring a mismatch.
          if(worldBoxError>0.001) {
            const response=await fetch(`/api/component-vertices?name=${encodeURIComponent(expected.nodeName)}`);
            if(!response.ok) throw Error("原始顶点读取失败，不能完成同坐标系复核。");
            const source:{vertices:number[][]}=await response.json();
            const inverse=placed.transform.inverse();
            if(!inverse) throw Error("云构件变换不可逆。");
            const local=Range3d.createNull();
            for(const v of source.vertices)local.extendPoint(inverse.multiplyPoint3d(Point3d.create(v[0],v[1],v[2])));
            const input=[local.low.x,local.low.y,local.low.z,local.high.x,local.high.y,local.high.z];
            const box=placed.bbox;
            const output=[box.low.x,box.low.y,box.low.z,box.high.x,box.high.y,box.high.z];
            error=Math.max(...input.map((v,k)=>Math.abs(v-output[k])));
            method="SOURCE_VERTICES_IN_IMODEL_LOCAL_FRAME";
            localComparison={expected:input,actual:output};
          }
          const pass=Number.isFinite(error)&&error<=0.001;
          if(!pass) failures++;maxError=Math.max(maxError,error);
          results.push({nodeName:expected.nodeName,assetId:expected.assetId,elementId:p.id,expected:expected.bounds,actual,worldBoxErrorM:worldBoxError,placement,method,localComparison,errorM:error,pass});
        }
      }
      const result={scope:"包围盒范围；世界外框不一致时在iModel构件局部坐标系复核原始顶点；不验证内部拓扑或设计正确性",mode:cloud?"CLOUD":"LOCAL",time:new Date().toISOString(),toleranceM:0.001,count:results.length,failures,maxErrorM:maxError,status:failures?"DIFFERENCES_FOUND":"PASS",results};
      setReport(JSON.stringify(result,null,2));setMessage(`范围核验完成：${results.length}个构件，${failures}个差异；最大偏差 ${(maxError*1000).toFixed(3)} mm。`);
    }catch(e){setMessage(e instanceof Error?e.message:String(e));}finally{setBusy(false);}
  }
  function download(){if(!report)return;const url=URL.createObjectURL(new Blob([report],{type:"application/json"}));const a=document.createElement("a");a.href=url;a.download="turnout-model-range-audit.json";a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
  return <section className="traction-points">
    <h2>构件查看与核验</h2>
    <div className="actions"><button disabled={busy||!elements.size} onClick={()=>void locate("SwitchRail")}>定位尖轨</button><button disabled={busy||!elements.size} onClick={()=>void locate("PointRail")}>定位心轨</button><button disabled={busy||!elements.size} onClick={()=>void locate()}>显示全道岔</button><button disabled={busy||!elements.size} onClick={()=>void audit()}>核对模型位置和尺寸</button>{report&&<button onClick={download}>下载核验报告</button>}</div>
    <p role="status">{message}</p>
    {selected&&<div><strong>{selected.nodeName}</strong><p>资产编码：{selected.assetId}</p><p>几何状态：{selected.geometryStatus}</p><p>传感器编号：未配置 · 工单：未关联</p>{points.filter(p=>p.modelNodeName===selected.nodeName||p.actuatorNodeName===selected.nodeName).map(p=><p key={p.code}>{p.code} · {p.label} · 设计动程 {p.strokeMm} mm</p>)}</div>}
    <p>范围核验比较当前模型与交付输入的包围盒，容差1 mm；不代表设计、制造精度或内部几何验收。选中高亮可能覆盖红色外观，点击空白处清除选择。</p>
  </section>;
}
