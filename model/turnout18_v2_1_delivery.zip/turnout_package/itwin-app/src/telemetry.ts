export const displacementFields = ["switchRailDisp1", "switchRailDisp2", "switchRailDisp3", "pointRailDisp1", "pointRailDisp2"] as const;
export type DisplacementField = typeof displacementFields[number];
export type Telemetry = { time: string } & Record<DisplacementField, number>;
export function dataIsFresh(connected: boolean, receivedAt: number, now: number): boolean {
  return connected && receivedAt > 0 && now >= receivedAt && now - receivedAt <= 5000;
}
export function parseTelemetry(value: unknown): Telemetry | undefined {
  if (!value || typeof value !== "object") return;
  const v = value as Record<string, unknown>;
  if (typeof v.time !== "string" || !Number.isFinite(Date.parse(v.time))) return;
  for (const field of displacementFields) {
    if (typeof v[field] !== "number" || !Number.isFinite(v[field])) return;
  }
  return v as Telemetry;
}
export function alarmState(v: Telemetry) {
  // Requested strict > comparisons in millimetres, not metres.
  return { SwitchRail: v.switchRailDisp1 > 150, PointRail: v.pointRailDisp1 > 100 };
}
