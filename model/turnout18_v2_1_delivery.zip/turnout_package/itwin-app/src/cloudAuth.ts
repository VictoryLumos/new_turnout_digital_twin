import { BrowserAuthorizationClient } from "@itwin/browser-authorization";
import { cloudConfig } from "./cloudConfig";

export const cloudMode = new URLSearchParams(location.search).get("mode") === "cloud";
export const cloudAuth = new BrowserAuthorizationClient({
  ...cloudConfig, responseType: "code", silentRedirectUri: cloudConfig.redirectUri,
});

export async function signInCloud() {
  if (location.origin !== "http://localhost:3002") {
    location.replace("http://localhost:3002/?mode=cloud");
    return false;
  }
  await cloudAuth.signInRedirect("http://localhost:3002/?mode=cloud");
  return cloudAuth.isAuthorized;
}
