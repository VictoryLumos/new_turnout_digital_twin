// Public application identifier; no client secret belongs in this SPA.
export const cloudConfig = {
  clientId: "spa-r9Awa0cRcKgFsuTlf4UicGt0l",
  iTwinId: "6b7038ab-a3e8-44a8-896e-1f534384e875",
  iModelId: "ca172c77-5e2e-4a49-93b4-8b8e45f5502c",
  redirectUri: "http://localhost:3002/signin-callback",
  postSignoutRedirectUri: "http://localhost:3002/",
  scope: "itwin-platform",
  authority: "https://ims.bentley.com",
};

// Confirmed through the user's cloud iModel Console, not guessed from UserLabel.
export const cloudRailQuery = `SELECT a.Element.Id AS elementId, a.NodeName AS nodeName, a.AssetId AS assetId
FROM DgnCustomItemTypes_TurnoutAssets.ComponentElementAspect a
WHERE a.NodeName IN (?, ?)`;

export const cloudCountQuery = `SELECT COUNT(*) AS mappingCount,
COUNT(DISTINCT a.Element.Id) AS elementCount,
COUNT(DISTINCT a.NodeName) AS uniqueNodeNames,
COUNT(DISTINCT a.AssetId) AS uniqueAssetIds
FROM DgnCustomItemTypes_TurnoutAssets.ComponentElementAspect a`;
