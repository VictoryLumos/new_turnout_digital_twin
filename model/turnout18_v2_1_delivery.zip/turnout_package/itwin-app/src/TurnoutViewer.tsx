import { useEffect, useRef, useState } from "react";
import { BentleyCloudRpcManager, ColorDef, IModelReadRpcInterface, IModelTileRpcInterface,
  SnapshotIModelRpcInterface, QueryBinder, QueryRowFormat, FeatureOverrideType,
  RpcRequest, RpcRequestStatus, WebAppRpcRequest } from "@itwin/core-common";
import { IModelApp, IModelConnection, SnapshotConnection, CheckpointConnection, ViewCreator3d, ScreenViewport, EmphasizeElements } from "@itwin/core-frontend";
import { FrontendIModelsAccess } from "@itwin/imodels-access-frontend";
import { ModelTools } from "./ModelTools";
import { cloudMode, cloudAuth, signInCloud } from "./cloudAuth";
import { cloudConfig, cloudRailQuery, cloudCountQuery } from "./cloudConfig";
import { alarmState, parseTelemetry, dataIsFresh, type Telemetry, type DisplacementField } from "./telemetry";

type DesignPoint = { code: string; label: string; modelNodeName:string; actuatorNodeName:string; field: DisplacementField; strokeMm: number; theoreticalForceN: number; demoAlarmThresholdMm: number | null };

let startup: Promise<void> | undefined;
let cloudProgress: (message: string) => void = () => {};
class ObservedHubAccess extends FrontendIModelsAccess {
  override async getChangesetFromVersion(...args: Parameters<FrontendIModelsAccess["getChangesetFromVersion"]>) {
    cloudProgress("正在向 Bentley 获取云模型版本（iModels API）…");
    const changeset = await super.getChangesetFromVersion(...args);
    cloudProgress("云模型版本已取得，正在等待 Bentley 打开模型（RPC）…");
    return changeset;
  }
}
function initialize() {
  return startup ??= (async () => {
    await IModelApp.startup({ publicPath: "/", ...(cloudMode ? { authorizationClient: cloudAuth, hubAccess: new ObservedHubAccess() } : {}) });
    BentleyCloudRpcManager.initializeClient(
      // Match iTwin/viewer web-viewer-react RpcInitializer for core 5.x.
      // An empty version produces /imodel/rpc//mode/... instead of the v5 route.
      cloudMode ? { info: { title: "imodel/rpc", version: "v5" }, uriPrefix: "https://api.bentley.com" } : { info: { title: "turnout", version: "1.0" }, uriPrefix: `${location.origin}/imodel` },
      cloudMode ? [IModelReadRpcInterface, IModelTileRpcInterface] : [IModelReadRpcInterface, IModelTileRpcInterface, SnapshotIModelRpcInterface]);
    // A standalone React host must start the render/input loop explicitly.
    IModelApp.startEventLoop();
  })();
}

/** A full local iModel viewer; backend creates turnout.bim from geometry.json.
 * For a hub iModel, configure authentication + cloud RPC and replace openRemote
 * with CheckpointConnection.openRemote(iTwinId, iModelId). GLB itself is NOT an
 * ECSQL database. The importer must preserve each component in UserLabel.
 */
export function TurnoutViewer() {
  const host = useRef<HTMLDivElement>(null);
  const [status, setStatus] = useState("正在打开 iModel…");
  const [error, setError] = useState("");
  const [sample, setSample] = useState<Telemetry>();
  const [elementCount, setElementCount] = useState<number>();
  const [points, setPoints] = useState<DesignPoint[]>([]);
  const [connected, setConnected] = useState(false);
  const [receivedAt, setReceivedAt] = useState(0);
  const [now, setNow] = useState(Date.now());
  const [slow, setSlow] = useState(false);
  const [modelReady, setModelReady] = useState(false);
  const [activeViewport,setActiveViewport]=useState<ScreenViewport>();
  const [rpcStatus, setRpcStatus] = useState("等待创建打开模型请求");
  useEffect(() => {
    setSlow(false);
    if (modelReady || error) return;
    const timer = setTimeout(() => setSlow(true), 60000);
    return () => clearTimeout(timer);
  }, [status, modelReady, error]);
  useEffect(() => {
    let disposed = false;
    // Diagnostic metadata only: never expose headers, tokens, bodies or request URLs.
    const removeRpcListener = cloudMode ? RpcRequest.events.addListener((_event, request) => {
      if (disposed || request.operation.operationName !== "getConnectionProps") return;
      const http = request instanceof WebAppRpcRequest ? request.metadata.status : 0;
      const state = RpcRequestStatus[request.status];
      setRpcStatus(`打开模型：${state} · HTTP ${http || "尚无响应"}`);
    }) : undefined;
    cloudProgress = message => { if (!disposed) setStatus(message); };
    let imodel: IModelConnection | undefined;
    let viewport: ScreenViewport | undefined;
    let socket: WebSocket | undefined;
    let retry: ReturnType<typeof setTimeout> | undefined;
    let staleTimer: ReturnType<typeof setInterval> | undefined;
    let lastReceived = 0;
    let lastSourceTime = -Infinity;
    let stale = false;
    const cleanupView = () => {
      if (viewport) {
        IModelApp.viewManager.dropViewport(viewport, true);
        viewport = undefined;
      }
    };
    void (async () => {
      try {
        if (cloudMode) {
          setStatus("正在登录 Bentley…");
          if (!await signInCloud() || disposed) return;
          setStatus("正在加载 Bentley 云端 iModel…");
        }
        await initialize();
        if (disposed) return;
        const response = await fetch("/api/model");
        if (!response.ok) throw new Error(`模型配置读取失败: ${response.status}`);
        const config = await response.json() as { key: string; viewId: string; elementCount: number };
        if (!cloudMode) setElementCount(config.elementCount);
        const designResponse = await fetch("/api/design");
        if (!designResponse.ok) throw new Error("设计参数读取失败，请重启新版服务。");
        const design = await designResponse.json() as {points: DesignPoint[]};
        setPoints(design.points);
        setStatus(cloudMode ? "正在打开云端模型连接（Bentley服务）…" : "正在打开本地模型…");
        imodel = cloudMode ? await CheckpointConnection.openRemote(cloudConfig.iTwinId, cloudConfig.iModelId) : await SnapshotConnection.openRemote(config.key);
        if (disposed) { await imodel.close(); return; }
        if (cloudMode) {
          setStatus("云端连接已打开，正在核对构件数量与编码…");
          const counts = await imodel.createQueryReader(cloudCountQuery, undefined, { rowFormat: QueryRowFormat.UseJsPropertyNames }).toArray();
          const count = counts[0];
          if (!count || [count.mappingCount, count.elementCount, count.uniqueNodeNames, count.uniqueAssetIds].some(n => Number(n) !== 2902))
            throw new Error("云端构件数量或编码唯一性与2902构件交付不一致，已停止启动模拟告警。");
          setElementCount(Number(count.elementCount));
        }
        const ids: Record<"SwitchRail" | "PointRail", string[]> = { SwitchRail: [], PointRail: [] };
        setStatus("正在查询尖轨、心轨的模型元素…");
        // Use parameters and geometric elements, not GLB node IDs or arbitrary labels.
        const sql = cloudMode ? cloudRailQuery : "SELECT ECInstanceId AS elementId, UserLabel AS nodeName FROM BisCore.GeometricElement3d WHERE UserLabel IN (?, ?)";
        const bindings = QueryBinder.from(["SwitchRail", "PointRail"]);
        for await (const row of imodel.createQueryReader(sql, bindings, { rowFormat: QueryRowFormat.UseJsPropertyNames })) {
          const name = row.nodeName as keyof typeof ids;
          if (cloudMode && name in ids) {
            const expected = name === "SwitchRail" ? "T18-VERIFIED_SWITCH_RAILS-0001" : "T18-C6D192_CONTROL_ENVELOPES-0006";
            if (row.assetId !== expected) throw new Error(`云端${name}资产编码不匹配。`);
          }
          if (name in ids) ids[name].push(row.elementId as string);
        }
        if (ids.SwitchRail.length !== 1 || ids.PointRail.length !== 1)
          throw new Error("iModel 尖轨/心轨主构件缺失或不唯一，请核对构件映射。");
        setStatus("构件查询已通过，正在创建三维视图…");
        const view = cloudMode ? await new ViewCreator3d(imodel).createDefaultView({ cameraOn: false }) : await imodel.views.load(config.viewId);
        if (disposed) { await imodel.close(); return; }
        viewport = ScreenViewport.create(host.current!, view);
        IModelApp.viewManager.addViewport(viewport);
        setActiveViewport(viewport);
        setModelReady(true);
        const vp = viewport;
        const emphasis = EmphasizeElements.getOrCreate(vp);
        const ownedIds = [...ids.SwitchRail, ...ids.PointRail];
        setStatus(`${cloudMode ? "Bentley 云端" : "本地"} iModel 已加载 · 尖轨 ${ids.SwitchRail.length} 个元素 / 心轨 ${ids.PointRail.length} 个元素`);
        const connect = () => {
          if (disposed) return;
          const ws = new WebSocket(`${location.protocol === "https:" ? "wss" : "ws"}://${location.host}/telemetry`);
          socket = ws;
          ws.onopen = () => {
            if (disposed) return;
            setConnected(true);
          };
          ws.onmessage = event => {
            if (disposed) return;
            try {
              const data = parseTelemetry(JSON.parse(String(event.data)));
              if (!data) throw new Error("模拟数据不完整：需要有效时间和五个牵引点的毫米数值。");
              const sourceTime = Date.parse(data.time);
              if (sourceTime <= lastSourceTime) return; // Replays cannot keep old data fresh.
              if (Math.abs(Date.now() - sourceTime) > 10000) throw new Error("遥测时间超过10秒，保留上次告警状态。");
              lastSourceTime = sourceTime;
              lastReceived = Date.now();
              setReceivedAt(lastReceived);
              setNow(lastReceived);
              stale = false;
              setSample(data);
              setError("");
              // Remove only this component's previous overrides; recovering
              // one rail must not clear another rail's active alarm.
              emphasis.clearOverriddenElements(vp, ownedIds);
              const alarms = alarmState(data);
              const redIds = [...(alarms.SwitchRail ? ids.SwitchRail : []), ...(alarms.PointRail ? ids.PointRail : [])];
              if (redIds.length) emphasis.overrideElements(redIds, vp, ColorDef.from(255, 0, 0), FeatureOverrideType.ColorOnly, false);
              vp.invalidateScene();
            } catch (reason) {
              setError(reason instanceof Error ? reason.message : String(reason));
            }
          };
          ws.onerror = () => { if (!disposed) setError("WebSocket 连接异常；将自动重连。"); };
          ws.onclose = () => {
            if (!disposed) { setConnected(false); setReceivedAt(0); setError("模拟数据连接已断开，保留上次结果；正在自动重连。"); retry = setTimeout(connect, 2000); }
          };
        };
        connect();
        lastReceived = Date.now();
        staleTimer = setInterval(() => {
          if (!disposed) setNow(Date.now());
          if (!disposed && Date.now() - lastReceived > 5000 && !stale) {
            stale = true;
            setError("超过5秒未收到有效数据，保留上次告警状态。");
          }
        }, 1000);
      } catch (reason) {
        if (!disposed) setError(reason instanceof Error ? reason.message : String(reason));
        cleanupView();
        if (imodel && !imodel.isClosed) await imodel.close();
      }
    })();
    return () => {
      disposed = true;
      removeRpcListener?.();
      cloudProgress = () => {};
      clearTimeout(retry);
      clearInterval(staleTimer);
      if (socket) { socket.onclose = null; socket.onmessage = null; socket.close(); }
      cleanupView();
      if (imodel && !imodel.isClosed) void imodel.close();
    };
  }, []);
  const alarms = sample ? alarmState(sample) : undefined;
  const fresh = dataIsFresh(connected, receivedAt, now);
  return <main>
    <nav><a href="/">本地演示</a> · <a href="http://localhost:3002/?mode=cloud">Bentley 云端模型（登录）</a></nav>
    <header><div><small>TURNOUT / DIGITAL TWIN</small><h1>18号道岔 · 构件监测演示</h1></div><span role="status" className={fresh ? "online" : "offline"}>{fresh ? "● 模拟数据正在更新" : connected ? "● 等待有效模拟数据" : "● 模拟数据未连接"}</span></header>
    <p role="status">{status}</p>
    {cloudMode && !modelReady && <p role="status">连接诊断（v5）：{rpcStatus}</p>}
    {slow && !modelReady && !error && <p className="error" role="status">等待超过60秒。当前步骤：{status}。连接诊断：{rpcStatus}。无需重新上传模型。</p>}
    {error && <div className="error" role="alert">{error}</div>}
    {sample && !fresh && <p className="error" role="status">以下数值与红色标记为上次有效结果，当前数据未更新。</p>}
    <section className="metrics">
      <article className={alarms?.SwitchRail ? "alarm" : ""}><label>尖轨 · 第一牵引点</label><strong>{sample?.switchRailDisp1.toFixed(1) ?? "—"}<em>mm</em></strong><span>告警条件 &gt; 150 mm</span></article>
      <article className={alarms?.PointRail ? "alarm" : ""}><label>心轨 · 第一牵引点</label><strong>{sample?.pointRailDisp1.toFixed(1) ?? "—"}<em>mm</em></strong><span>告警条件 &gt; 100 mm</span></article>
      <article><label>模型</label><strong>{elementCount?.toLocaleString() ?? "—"}<em>独立构件</em></strong><span>米 · X 线路方向 / Y 横移方向</span></article>
    </section>
    <section className="traction-points" aria-label="五个牵引点参数与模拟动程">
      <h2>五个牵引点</h2>
      <p>未接入真实传感器 · 分动外锁闭设计 · 转换力为图纸理论值，非实测值</p>
      <div className="table-scroll"><table>
        <thead><tr><th>测点</th><th>模拟动程（mm）</th><th>设计动程（mm）</th><th>理论转换力（N）</th><th>演示阈值</th></tr></thead>
        <tbody>{points.map(point => <tr key={point.code}>
          <td>{point.label}</td><td>{sample?.[point.field].toFixed(1) ?? "—"}</td><td>{point.strokeMm}</td><td>{point.theoreticalForceN}</td>
          <td>{point.demoAlarmThresholdMm === null ? "未配置" : `> ${point.demoAlarmThresholdMm} mm`}</td>
        </tr>)}</tbody>
      </table></div>
    </section>
    {activeViewport&&<ModelTools viewport={activeViewport} cloud={cloudMode} points={points}/>}
    <div className="view" ref={host} aria-label="道岔 iModel 三维视图" />
    <footer><span>{status}</span><span>{sample ? `最后有效模拟数据：${new Date(sample.time).toLocaleString()}` : "等待模拟数据"}</span></footer>
    <p className="note">{cloudMode ? "云端模型连接模式" : "本地快照模式"} · 5台转辙机为示意外形 · 数据为本机模拟，未接真实传感器或AssetWise。红色仅表示演示阈值触发，不代表工程故障。</p>
  </main>;
}
