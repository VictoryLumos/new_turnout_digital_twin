import React from "react";
import { createRoot } from "react-dom/client";
import { TurnoutViewer } from "./TurnoutViewer";
import "./style.css";
import { cloudAuth } from "./cloudAuth";
const root = createRoot(document.getElementById("root")!);
if (location.pathname === "/signin-callback") {
  root.render(<p>正在完成 Bentley 登录…</p>);
  void cloudAuth.handleSigninCallback().catch(() => {
    root.render(<main><h1>Bentley 登录未完成</h1><p>请检查注册回调地址是否为 http://localhost:3002/signin-callback，再重新登录。</p><a href="/?mode=cloud">重新登录</a></main>);
  });
} else {
  root.render(<TurnoutViewer />);
}
